
function menu_bar(){
   document.getElementById('ul').style.marginLeft='0%'
   
}
function menu_bars(){
    document.getElementById('ul_bar').style.marginLeft='-100%'
    
 }
// function iconbar(){
//    document.getElementById('icon_bar').style.display='none'
// }